<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Vehicles - Luxury Transfer Service</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; background:#f5f5f5; padding:40px 20px; }
        .container { max-width:1200px; margin:0 auto; }
        .vehicle-card { background:#fff; border-radius:8px; padding:30px; margin-bottom:30px; display:grid; grid-template-columns:250px 1fr 300px; gap:40px; align-items:center; box-shadow:0 2px 8px rgba(0,0,0,0.08); }
        .vehicle-image { text-align:center; }
        .vehicle-image img { max-width:100%; height:auto; max-height:200px; border-radius:8px; }
        .vehicle-description { font-size:14px; color:#333; line-height:1.6; margin-top:15px; font-weight:500; }
        .vehicle-details { display:flex; flex-direction:column; gap:20px; }
        .vehicle-header { display:flex; align-items:center; gap:12px; margin-bottom:10px; }
        .vehicle-title { font-size:24px; font-weight:700; color:#1a1a1a; }
        .best-value-badge { background:#fff9e6; border:1px solid #d4af37; color:#d4af37; padding:4px 12px; border-radius:20px; font-size:12px; font-weight:600; display:inline-flex; align-items:center; gap:4px; }
        .best-value-badge::before { content:"★"; font-size:14px; }
        .features-list { display:flex; flex-direction:column; gap:12px; }
        .feature-item { display:flex; align-items:center; gap:12px; font-size:14px; color:#666; }
        .feature-icon { width:20px; height:20px; display:flex; align-items:center; justify-content:center; font-size:16px; color:#4a7ba7; flex-shrink:0; }
        .pricing-section { display:flex; flex-direction:column; gap:15px; text-align:right; }
        .price-label { font-size:12px; color:#666; font-weight:500; }
        .price { font-size:48px; font-weight:700; color:#1a1a1a; line-height:1; }
        .price-currency { font-size:24px; margin-right:4px; }
        .cancellation-badge { background:#e8f5f0; color:#2d8659; padding:6px 12px; border-radius:4px; font-size:12px; font-weight:600; display:inline-flex; align-items:center; gap:6px; justify-content:flex-end; }
        .cancellation-badge::before { content:"●"; font-size:8px; }
        .includes-text { font-size:13px; color:#333; display:flex; align-items:center; gap:6px; justify-content:flex-end; }
        .includes-text::before { content:"✓"; font-weight:bold; color:#333; }
        .select-button { background:#c9a961; color:white; border:none; padding:14px 32px; border-radius:4px; font-size:14px; font-weight:700; cursor:pointer; transition:background-color 0.3s ease; letter-spacing:1px; }
        .select-button:hover { background:#b8985a; }
        @media (max-width:1024px) {
            .vehicle-card { grid-template-columns:1fr; gap:20px; }
            .pricing-section { text-align:left; }
            .cancellation-badge, .includes-text { justify-content:flex-start; }
        }
    </style>
</head>
<body>
<div class="container">
    <h2 style="margin-bottom:30px; text-align:center; color:#1a1a1a;">Available Vehicles</h2>

    <?php if(empty($vehicles)): ?>
        <p style="text-align:center;">No vehicles found.</p>
    <?php else: ?>
        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $rate = $vehicle['total_amount']
                        ?? $vehicle['original_total_amount']
                        ?? $vehicle['price']
                        ?? $vehicle['total']
                        ?? null;
            ?>

            <div class="vehicle-card">
                <div class="vehicle-image">
                    <?php if(!empty($vehicle['vehicle_type_images'])): ?>
                        <img src="<?php echo e($vehicle['vehicle_type_images'][0]); ?>" alt="<?php echo e($vehicle['vehicle_type_name'] ?? 'Vehicle'); ?>">
                    <?php else: ?>
                        <img src="/placeholder.svg?height=200&width=250" alt="Vehicle">
                    <?php endif; ?>
                    <div class="vehicle-description"><?php echo e($vehicle['vehicle_type_description'] ?? 'Luxury Private Service'); ?></div>
                </div>

                <div class="vehicle-details">
                    <div class="vehicle-header">
                        <h2 class="vehicle-title"><?php echo e($vehicle['vehicle_type_name'] ?? 'Unknown Vehicle'); ?></h2>
                        <div class="best-value-badge">BEST VALUE</div>
                    </div>

                    <div class="features-list">
                        <div class="feature-item">
                            <div class="feature-icon">👥</div>
                            <span><?php echo e($vehicle['passenger_capacity'] ?? 'N/A'); ?> passengers</span>
                        </div>
                        <?php if(!empty($vehicle['vehicle_type_images'])): ?>
                            <div class="feature-item">
                                <div class="feature-icon">🖼️</div>
                                <span><?php echo e(count($vehicle['vehicle_type_images'])); ?> images</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="pricing-section">
                    <div class="price-label">Total one-way price</div>
                    <div class="price"><span class="price-currency">€</span><?php echo e($rate ? number_format($rate, 2) : 'N/A'); ?></div>
                    <div class="cancellation-badge">FREE Cancellation</div>
                    <div class="includes-text">Includes VAT, fees & tip</div>
                    <button class="select-button">SELECT</button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <a href="<?php echo e(route('ride.form')); ?>" style="display:inline-block; margin-top:20px; text-decoration:none; color:#fff; background:#6c757d; padding:12px 24px; border-radius:6px;">Back</a>
</div>
</body>
</html>
<?php /**PATH C:\Users\A1\Desktop\LAravel\newproject\laravelproject\resources\views/ride-results.blade.php ENDPATH**/ ?>