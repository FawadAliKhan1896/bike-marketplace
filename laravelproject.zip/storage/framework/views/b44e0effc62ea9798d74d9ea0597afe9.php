<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ride Information</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f5f5f5;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .form-container {
            background: white;
            border-radius: 12px;
            padding: 30px;
            width: 100%;
            max-width: 600px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #1a3a52;
        }

        .alert {
            background-color: #ffe0e0;
            color: #a30000;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 16px;
            font-weight: 600;
            color: #1a3a52;
            margin-bottom: 10px;
        }

        .input-wrapper {
            display: flex;
            align-items: center;
            background: #e8eef5;
            border-radius: 8px;
            padding: 14px 16px;
            gap: 12px;
        }

        .input-wrapper input {
            flex: 1;
            border: none;
            background: transparent;
            font-size: 16px;
            color: #333;
            outline: none;
        }

        .input-wrapper input::placeholder {
            color: #888;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .search-btn {
            width: 100%;
            padding: 16px;
            background: #b8956a;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .search-btn:hover {
            background: #a0804f;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Ride Information</h2>

        <?php if(session('error')): ?>
            <div class="alert"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('ride.getRates')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>Pickup Location</label>
                <div class="input-wrapper">
                    <input type="text" name="pickup_location" placeholder="Enter pickup location" required>
                </div>
            </div>

            <div class="form-group">
                <label>Drop-off Location</label>
                <div class="input-wrapper">
                    <input type="text" name="dropoff_location" placeholder="Enter drop-off location" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Pickup Date</label>
                    <div class="input-wrapper">
                        <input type="date" name="pickup_date" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Pickup Time</label>
                    <div class="input-wrapper">
                        <input type="time" name="pickup_time" required>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Passenger Count</label>
                <div class="input-wrapper">
                    <input type="number" name="passenger_count" placeholder="Enter number of passengers" min="1" required>
                </div>
            </div>

            <button class="search-btn">Check Rates</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\A1\Desktop\LAravel\newproject\laravelproject\resources\views/ride-form.blade.php ENDPATH**/ ?>