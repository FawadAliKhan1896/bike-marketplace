<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class RideController extends Controller
{
    public function index()
    {
        return view('ride-form');
    }

    public function getRates(Request $request)
    {
        $validated = $request->validate([
            'pickup_location'  => 'required|string',
            'dropoff_location' => 'required|string',
            'pickup_date'      => 'required|date',
            'pickup_time'      => 'required',
            'passenger_count'  => 'required|integer|min:1',
        ]);

        $clientId     = env('LIMO_CLIENT_ID', 'ca_customer_mayfairbv');
        $clientSecret = env('LIMO_CLIENT_SECRET', 'pmudJrHpv7zscw2vbdlJJFFWcIq4BLygs8gvwzW26ESWhJua67');
        $companyAlias = env('LIMO_COMPANY_ALIAS', 'limotest1');

        $tokenResponse = Http::asForm()->post('https://api.mylimobiz.com/v0/oauth2/token', [
            'grant_type'    => 'client_credentials',
            'client_id'     => $clientId,
            'client_secret' => $clientSecret,
        ]);

        if ($tokenResponse->failed()) {
            Log::error('Limo token request failed', ['status' => $tokenResponse->status(), 'body' => $tokenResponse->body()]);
            return back()->with('error', 'Failed to get access token (see logs).');
        }

        $accessToken = $tokenResponse->json('access_token');
        if (!$accessToken) {
            Log::error('Limo token response missing access_token', ['body' => $tokenResponse->body()]);
            return back()->with('error', 'Access token missing from Limo response (see logs).');
        }

        $localDateTime = $validated['pickup_date'] . ' ' . $validated['pickup_time'];

        try {
            $dt = Carbon::createFromFormat('Y-m-d H:i', $localDateTime, config('app.timezone') ?? date_default_timezone_get());
        } catch (\Throwable $e) {
            try {
                $dt = Carbon::parse($localDateTime, config('app.timezone') ?? date_default_timezone_get());
            } catch (\Throwable $e2) {
                Log::error('Failed to parse pickup datetime', ['input' => $localDateTime, 'errors' => [$e->getMessage(), $e2->getMessage()]]);
                return back()->with('error', 'Invalid pickup date/time format.');
            }
        }

        $dateCandidates = [
            $dt->format('Y-m-d\TH:i:s'),     
            $dt->setTimezone('UTC')->format('Y-m-d\TH:i:sP'), 
        ];

        $buildAddress = function (string $input) {
            $address = [
                'address_line1' => $input,
                'city' => $input,
            ];

            if (strpos($input, ',') !== false) {
                $parts = array_map('trim', explode(',', $input));
                $address['address_line1'] = $parts[0] ?? $input;
                if (count($parts) >= 2) {
                    $address['city'] = $parts[count($parts) - 2];
                }
                if (count($parts) >= 3) {
                    $address['state_code'] = $parts[count($parts) - 1];
                }
            }

            return $address;
        };

        $pickupAddress = $buildAddress($validated['pickup_location']);
        $dropoffAddress = $buildAddress($validated['dropoff_location']);

        $basePayload = [
            'passenger_count' => (int) $validated['passenger_count'],
            'pickup' => [
                'type' => 'address',
                'instructions' => '',
                'address' => $pickupAddress,
            ],
            'dropoff' => [
                'type' => 'address',
                'instructions' => '',
                'address' => $dropoffAddress,
            ],
        ];

        $url = "https://api.mylimobiz.com/v0/companies/{$companyAlias}/rate_lookup";

        $lastResponse = null;
        $attempts = [];

        foreach ($dateCandidates as $scheduledPickupAt) {
            $payloadWithDate = $basePayload;
            $payloadWithDate['scheduled_pickup_at'] = $scheduledPickupAt;

            $shapes = [
                $payloadWithDate,
                ['request' => $payloadWithDate],
            ];

            foreach ($shapes as $payload) {
                $attempts[] = ['url' => $url, 'payload' => $payload];
                try {
                    $response = Http::withToken($accessToken)
                        ->accept('application/json')
                        ->timeout(15)
                        ->post($url, $payload);
                } catch (\Throwable $e) {
                    Log::warning('Rate lookup HTTP exception', ['exception' => $e->getMessage(), 'payload' => $payload]);
                    continue;
                }

                $lastResponse = $response;

                if (!$response->failed()) {
                    return $this->handleSuccessAndFetchResults($response, $accessToken, $companyAlias);
                }

                $body = $response->body();
                $status = $response->status();
                $json = json_decode($body, true) ?: [];

                Log::warning('Limo rate_lookup attempt failed', [
                    'status' => $status,
                    'body' => $body,
                    'payload' => $payload,
                ]);

            }
        }

        $finalBody = $lastResponse ? $lastResponse->body() : '';
        $finalStatus = $lastResponse ? $lastResponse->status() : null;
        $finalJson = json_decode($finalBody, true) ?: [];
        $correlationId = $finalJson['correlation_id'] ?? $finalJson['CorrelationId'] ?? null;

        Log::error('Limo rate_lookup failed after retries', [
            'status' => $finalStatus,
            'body' => $finalBody,
            'attempts' => $attempts,
        ]);

        if ($correlationId) {
            Log::error('Limo rate_lookup correlation id', ['correlation_id' => $correlationId]);
            return back()->with('error', "❌ Rate lookup failed (server error). Correlation id: {$correlationId}. Please contact Limo Anywhere support with that id.");
        }

        return back()->with('error', '❌ Rate lookup failed (see logs).');
    }

    protected function handleSuccessAndFetchResults($createResponse, $accessToken, $companyAlias)
    {
        $createJson = $createResponse->json();
        // dd($createJson);

        if (isset($createJson['results']) && is_array($createJson['results'])) {
            $vehicles = $createJson['results'];
            return view('ride-results', compact('vehicles'));
        }

        $rateLookupId = $createJson['Id'] ?? $createJson['id'] ?? $createJson['rate_lookup_id'] ?? null;
        if (!$rateLookupId) {
            Log::error('No rate lookup id and no direct results', ['response' => $createJson]);
            return back()->with('error', '❌ No rate lookup ID or results returned (see logs).');
        }

        $resultsUrl = "https://api.mylimobiz.com/v0/companies/{$companyAlias}/rate_lookup/results/{$rateLookupId}";

        $resultResponse = Http::withToken($accessToken)
            ->accept('application/json')
            ->get($resultsUrl);
        // dd($resultResponse);

        if ($resultResponse->failed()) {
            Log::error('Failed to fetch rate lookup results', [
                'status' => $resultResponse->status(),
                'url'    => $resultsUrl,
                'body'   => $resultResponse->body(),
            ]);
            return back()->with('error', '❌ Failed to fetch rate lookup results (see logs).');
        }
        $vehiclesResponse = $resultResponse->json();
        // dd($vehiclesResponse);
        $vehicles = $vehiclesResponse['results'] ?? [];


        if (isset($vehicles['results'])) {
            $vehicles = $vehicles['results'];
        }

        \Log::info('LimoAnywhere rate lookup result', $resultResponse->json());


        return view('ride-results', compact('vehicles'));
    }
}
