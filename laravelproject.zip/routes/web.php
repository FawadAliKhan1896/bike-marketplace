<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RideController;

Route::get('/', function () {
    return view('welcome');
});


Route::get('/', [RideController::class, 'index'])->name('ride.form');
Route::post('/get-rates', [RideController::class, 'getRates'])->name('ride.getRates');

